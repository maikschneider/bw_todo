insert into `be_users` (`uid`, `pid`, `tstamp`, `crdate`, `cruser_id`, `deleted`, `disable`, `starttime`, `endtime`,
						`description`, `username`, `avatar`, `password`, `admin`, `usergroup`, `lang`, `email`,
						`db_mountpoints`, `options`, `realName`, `userMods`, `allowed_languages`, `uc`,
						`file_mountpoints`, `file_permissions`, `workspace_perms`, `TSconfig`, `lastlogin`,
						`workspace_id`, `mfa`, `category_perms`, `password_reset_token`)
values (2, 0, 1646193498, 1646193498, 0, 0, 0, 0, 0, null, 'admin', 0,
		'$argon2i$v=19$m=65536,t=16,p=1$Tng4bE1WSi5sTEsvSmdHSQ$lHbuEr7H/yQsblOny4qb/0o94NowF/r+geT6WuzIfoY', 1, null,
		'default', '', null, 0, '', null, '', null, null, null, 1, null, 0, 0, null, null, '');

insert into `pages` (`uid`, `pid`, `tstamp`, `crdate`, `cruser_id`, `deleted`, `hidden`, `starttime`, `endtime`,
					 `fe_group`, `sorting`, `rowDescription`, `editlock`, `sys_language_uid`, `l10n_parent`,
					 `l10n_source`, `l10n_state`, `t3_origuid`, `l10n_diffsource`, `t3ver_oid`, `t3ver_wsid`,
					 `t3ver_state`, `t3ver_stage`, `perms_userid`, `perms_groupid`, `perms_user`, `perms_group`,
					 `perms_everybody`, `title`, `slug`, `doktype`, `TSconfig`, `is_siteroot`, `php_tree_stop`, `url`,
					 `shortcut`, `shortcut_mode`, `subtitle`, `layout`, `target`, `media`, `lastUpdated`, `keywords`,
					 `cache_timeout`, `cache_tags`, `newUntil`, `description`, `no_search`, `SYS_LASTCHANGED`,
					 `abstract`, `module`, `extendToSubpages`, `author`, `author_email`, `nav_title`, `nav_hide`,
					 `content_from_pid`, `mount_pid`, `mount_pid_ol`, `l18n_cfg`, `fe_login_mode`, `backend_layout`,
					 `backend_layout_next_level`, `tsconfig_includes`, `categories`, `tx_impexp_origuid`)
values (1, 0, 1646191598, 1646191570, 2, 0, 0, 0, 0, '', 256, null, 0, 0, 0, 0, null, 0,
		X'7B22646F6B74797065223A22222C227469746C65223A22222C22736C7567223A22222C226E61765F7469746C65223A22222C227375627469746C65223A22222C226162737472616374223A22222C226B6579776F726473223A22222C226465736372697074696F6E223A22222C22617574686F72223A22222C22617574686F725F656D61696C223A22222C226C61737455706461746564223A22222C226C61796F7574223A22222C226E6577556E74696C223A22222C226261636B656E645F6C61796F7574223A22222C226261636B656E645F6C61796F75745F6E6578745F6C6576656C223A22222C22636F6E74656E745F66726F6D5F706964223A22222C22746172676574223A22222C2263616368655F74696D656F7574223A22222C2263616368655F74616773223A22222C2269735F73697465726F6F74223A22222C226E6F5F736561726368223A22222C227068705F747265655F73746F70223A22222C226D6F64756C65223A22222C226D65646961223A22222C227473636F6E6669675F696E636C75646573223A22222C225453636F6E666967223A22222C226C31386E5F636667223A22222C2268696464656E223A22222C226E61765F68696465223A22222C22737461727474696D65223A22222C22656E6474696D65223A22222C22657874656E64546F5375627061676573223A22222C2266655F67726F7570223A22222C2266655F6C6F67696E5F6D6F6465223A22222C22656469746C6F636B223A22222C2263617465676F72696573223A22222C22726F774465736372697074696F6E223A22227D',
		0, 0, 0, 0, 2, 0, 31, 27, 0, 'Home', '/', 1, null, 1, 0, '', 0, 0, '', 0, '', 0, 0, null, 0, '', 0, null, 0,
		1646191598, null, '', 0, '', '', '', 0, 0, 0, 0, 0, 0, '', '', null, 0, 0),
	(2, 1, 1646191617, 1646191605, 2, 0, 0, 0, 0, '0', 256, null, 0, 0, 0, 0, null, 0,
	 X'7B22646F6B74797065223A22222C227469746C65223A22222C22736C7567223A22222C226261636B656E645F6C61796F7574223A22222C226261636B656E645F6C61796F75745F6E6578745F6C6576656C223A22222C226D6F64756C65223A22222C226D65646961223A22222C227473636F6E6669675F696E636C75646573223A22222C225453636F6E666967223A22222C2268696464656E223A22222C22656469746C6F636B223A22222C2263617465676F72696573223A22222C22726F774465736372697074696F6E223A22227D',
	 0, 0, 0, 0, 2, 0, 31, 27, 0, 'Todo', '/todo', 254, null, 0, 0, '', 0, 0, '', 0, '', 0, 0, null, 0, '', 0, null, 0,
	 0, null, 'td', 0, '', '', '', 0, 0, 0, 0, 0, 0, '', '', null, 0, 0);

insert into `sys_template` (`uid`, `pid`, `tstamp`, `crdate`, `cruser_id`, `deleted`, `hidden`, `starttime`, `endtime`,
							`sorting`, `description`, `t3_origuid`, `t3ver_oid`, `t3ver_wsid`, `t3ver_state`,
							`t3ver_stage`, `title`, `root`, `clear`, `include_static_file`, `constants`, `config`,
							`basedOn`, `includeStaticAfterBasedOn`, `static_file_mode`, `tx_impexp_origuid`)
values (1, 1, 1646191718, 1646191697, 2, 0, 0, 0, 0, 256, null, 0, 0, 0, 0, 0, 'NEW SITE', 1, 3, null, null, '', '', 0,
		0, 0);
